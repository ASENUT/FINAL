/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author MASTER
 */
public class Conexion {
    static String db="Asenut";
    static String login = "ute2016";
    static String pass = "ute2016";
    static String url = "jdbc:mysql://107.180.58.67:3306/Asenut";
    static Connection link=null;
    public Conexion() {
    }
   
    
    public static Connection Conectar(){
        try{
          Class.forName("org.gjt.mm.mysql.Driver");
            link=DriverManager.getConnection(url, login, pass);
        }catch(ClassNotFoundException | SQLException e){
          JOptionPane.showConfirmDialog(null, e);
      }
        return link;
    }
}
