/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import Datos.DCitas;
import Datos.DVentas;
import ventanas.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MASTER
 */
public class LCitas {
    //Creacion de la conexion y la variable de la misma
    private Conexion mysql=new Conexion();
    private Connection cn=mysql.Conectar();
    private String sSQL="";
    private String sSQL2="";
    private String sSQL3="";
    public static int NúmeroCitas=0;
    
    DCitas d=new DCitas();
    
    //Creacion de la tabla de la interfaz
    public DefaultTableModel CargarTabla(){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [3];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select COD_HORARIO, HORA_CITA, FECHA_CITA from HORARIO";              
                  
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("HORA_CITA");
                registro[2]=rs.getString("FECHA_CITA");
               
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    public DefaultTableModel mostrar(String busca){
        DefaultTableModel modelo;
        
        String [] título={"CD","Hora Cita", "Fecha Cita", "Cliente", "Tipo"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [5];
        
        modelo = new DefaultTableModel(null,título);
        sSQL="select *from HORARIO where HORA_CITA="+busca+" order by COD_HORARIO";
        
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("HORA_CITA");
                registro[2]=rs.getString("FECHA_CITA");
                registro[3]=rs.getString(d.getCliente());
                registro[4]=rs.getString(d.getTipoCita());
               
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
     public DefaultTableModel mostrarh(String busca){
        DefaultTableModel modelo;
        
        String [] título={"COD Horario","Hora Cita", "Fecha Cita"};//Para que se cambie en la columna de las tablas
        String [] registro=new String [3];
        
        modelo = new DefaultTableModel(null,título);
         sSQL="select COD_HORARIO, HORA_CITA, FECHA_CITA from HORARIO"+
                " where COD_HORARIO=(select COD_HORARIO from CITA_MEDICA"+ 
                " where cedula="+busca+")";
              
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
                registro[0]=rs.getString("COD_HORARIO");
                registro[1]=rs.getString("HORA_CITA");
                registro[2]=rs.getString("FECHA_CITA");
                              
                modelo.addRow(registro);
                
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    public boolean insertar (DCitas dci){
        String valor="";
        sSQL3="select COD_HORARIO from HORARIO order by COD_HORARIO desc limit 1";
        sSQL="insert into HORARIO (COD_HORARIO, HORA_CITA, FECHA_CITA)"+
                "values (?,?,?)";
        sSQL2="insert into CITA_MEDICA (CEDULA,COD_HORARIO, CITA, NUM_SESIONES, TIPO_TRATAMIENTO) values(?,?,?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL3);
            while(rs.next()){
                valor=rs.getString("COD_HORARIO");
            }
            if (valor.equals("")) {
                valor="0";
            }
           if(NúmeroCitas==0) {
                NúmeroCitas=Integer.parseInt(valor)+1;
           }else{
            NúmeroCitas=NúmeroCitas+1;
            }
            pst.setInt(1, NúmeroCitas);
            pst.setString(2, dci.getHoraCita());
            pst.setString(3, dci.getFechaCita());
            
            PreparedStatement p=cn.prepareStatement(sSQL2);
            p.setString(1, dci.getCliente());
            p.setInt(2, NúmeroCitas);
            p.setString(3, dci.getTipoCita());
            p.setString(4, dci.getSesiones());
            p.setString(5, dci.getTratamiento());
            int n=pst.executeUpdate();
            int h=p.executeUpdate();
            if(n!=0 && h!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            return false;//Si no se conecto a la base
        }
    }
    public String Validar(String Cedula){
       String existe="";
       sSQL="select distinct CEDULA from PACIENTE where CEDULA="+Cedula;
       try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while (rs.next()){
                existe=rs.getString("CEDULA");
            }
                
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
       return existe;
   }
    public int mostrarCod(String busca){
        int cod=0;
        sSQL="select COD_HORARIO from HORARIO"+
                " where COD_HORARIO=(select COD_HORARIO from CITA_MEDICA"+ 
                " where cedula="+busca+")";
                          
        try {
            Statement st=cn.createStatement();
            ResultSet rs=st.executeQuery(sSQL);
            
            while(rs.next()){
               cod=rs.getInt("COD_HORARIO");
            }
            return cod;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return 0;
        }
    }
    public boolean editarHorario (DCitas dci){
        System.out.println(d.getCOD_Horario());
        sSQL="update HORARIO set HORA_CITA=?, FECHA_CITA=? where COD_HORARIO=?";
       try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            
            pst.setString(1, dci.getHoraCita());
            pst.setString(2, dci.getFechaCita());
            pst.setInt(3, dci.getCOD_Horario());
                                
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
        
     
    }
   
    public boolean elminarHorario(DCitas dci){
        sSQL="delete HORA_CITA, FECHA_CITA from HORARIO where COD_HORARIO=?";
        try {
            PreparedStatement pst=cn.prepareStatement(sSQL);
            
            pst.setInt(1, dci.getCOD_Horario());
            
            int n=pst.executeUpdate();
            if(n!=0){
                return true;//Si se inserto los registros
            }else{
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return false;//Si no se conecto a la base
        }
    }
}
