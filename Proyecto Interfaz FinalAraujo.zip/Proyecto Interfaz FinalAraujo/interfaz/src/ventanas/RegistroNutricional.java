package ventanas;

import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class RegistroNutricional extends javax.swing.JFrame {

    public static String cecliente = "";
    public static String fechatratamiento = "";
    MetodoComunes metodoscomunes = new MetodoComunes();

    public RegistroNutricional() {
        initComponents();
        ImageIcon imagenfondo1 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo2 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo3 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo4 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo5 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo6 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo7 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo8 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo9 = new ImageIcon("src/imagenes/574.png");
        Icon icono1 = new ImageIcon(imagenfondo1.getImage().getScaledInstance(jLabel52.getWidth(), jLabel52.getHeight(), Image.SCALE_DEFAULT));
        Icon icono2 = new ImageIcon(imagenfondo2.getImage().getScaledInstance(jLabel43.getWidth(), jLabel43.getHeight(), Image.SCALE_DEFAULT));
        Icon icono3 = new ImageIcon(imagenfondo3.getImage().getScaledInstance(jLabel42.getWidth(), jLabel42.getHeight(), Image.SCALE_DEFAULT));
        Icon icono4 = new ImageIcon(imagenfondo4.getImage().getScaledInstance(jLabel44.getWidth(), jLabel44.getHeight(), Image.SCALE_DEFAULT));
        Icon icono5 = new ImageIcon(imagenfondo5.getImage().getScaledInstance(jLabel499.getWidth(), jLabel499.getHeight(), Image.SCALE_DEFAULT));
        Icon icono6 = new ImageIcon(imagenfondo6.getImage().getScaledInstance(jLabel21.getWidth(), jLabel21.getHeight(), Image.SCALE_DEFAULT));
        Icon icono7 = new ImageIcon(imagenfondo7.getImage().getScaledInstance(jLabel81.getWidth(), jLabel81.getHeight(), Image.SCALE_DEFAULT));
        Icon icono8 = new ImageIcon(imagenfondo8.getImage().getScaledInstance(jLabel48.getWidth(), jLabel48.getHeight(), Image.SCALE_DEFAULT));
        Icon icono9 = new ImageIcon(imagenfondo9.getImage().getScaledInstance(jLabel110.getWidth(), jLabel110.getHeight(), Image.SCALE_DEFAULT));
        jLabel52.setIcon(icono1);
        jLabel43.setIcon(icono2);
        jLabel42.setIcon(icono3);
        jLabel44.setIcon(icono4);
        jLabel499.setIcon(icono5);
        jLabel21.setIcon(icono6);
        jLabel81.setIcon(icono7);
        jLabel48.setIcon(icono8);
        jLabel110.setIcon(icono9);
        this.repaint();
        this.setLocationRelativeTo(null);

        //Campos solo textos 
        metodoscomunes.SoloLetras(txtAlergiaAlimenticia);
        metodoscomunes.SoloLetras(txtAlimentosDesagradan);
        metodoscomunes.SoloLetras(txtAlimentosMayorFrecuencia);
        metodoscomunes.SoloLetras(txtConsumeAlimentosFueraCasa);
        /*Ventana Actividad Fisica*/
        metodoscomunes.SoloLetras(txtOcupacion);
        metodoscomunes.SoloLetras(txtActividad);
        metodoscomunes.SoloLetras(txtProfesion);
        metodoscomunes.SoloLetras(txtTipoDepor);
        metodoscomunes.SoloLetras(txtFrecDepor);
        metodoscomunes.SoloNumeros(txtTiempoDepor);
        /*Ventana tratamiento*/
        metodoscomunes.SoloLetrasArea(txtTratamiento);
        /*Ventana */
        metodoscomunes.SoloLetrasArea(txtDiagnosticoNutri);
        /*Ventana DN*/
        metodoscomunes.SoloLetrasArea(txtDiagnosticoNutri);
        /*Ventana Descripción*/
        metodoscomunes.SoloLetrasArea(txtDescripcion);
        /*Ventana DA*/
        /// metodoscomunes.SoloLetrasArea(txtHistoriaAlimenticia);
        metodoscomunes.SoloNumeros(txtPesoActual);
        metodoscomunes.SoloNumeros(txtPesoHabitual);
        metodoscomunes.SoloNumeros(txtPesoIdeal);
        metodoscomunes.SoloNumeros(txtTalla);
        metodoscomunes.SoloNumeros(txtPesoAumento);
        metodoscomunes.SoloNumeros(txtDisminucion);
        metodoscomunes.SoloLetras(txtContexOsea);
        metodoscomunes.SoloNumeros(txtCMB);
        metodoscomunes.SoloNumeros(txtBiceps);
        metodoscomunes.SoloNumeros(txtTriceps);
        metodoscomunes.SoloNumeros(txtSubescapular);
        metodoscomunes.SoloNumeros(txtSuprailiaco);
        metodoscomunes.SoloNumeros(txtCin_Cad);
        metodoscomunes.SoloNumeros(txtCintura);
        metodoscomunes.SoloNumeros(txtCadera);
        /*Ventana DNParte1*/
        metodoscomunes.SoloLetras(txtAlimentosMayorFrecuencia);
        metodoscomunes.SoloLetras(txtAlergiaAlimenticia);
        metodoscomunes.SoloLetras(txtAlimentosDesagradan);
        metodoscomunes.SoloLetras(txtPersonaPreparaSirveAlimentos);
        /*Ventana DNParte2*/
        metodoscomunes.SoloLetras(txtSuplemetosVitaminicos);
        metodoscomunes.SoloLetras(txtConsumeSalados);
        metodoscomunes.SoloLetras(txtConsumeFrecuenciaFritaras);
        metodoscomunes.SoloLetras(txtFrecuenciaEnlatados);
        /*Ventana DNParte3*/
        metodoscomunes.SoloLetras(txtConsumeFrecuenciaEmbidos);
        metodoscomunes.SoloLetras(txtComeFrutas);
        metodoscomunes.SoloLetras(txtConsumeSalados);
        metodoscomunes.SoloLetras(txtConsumeGaseosas);
        metodoscomunes.SoloLetras(txtProblemasGastrointentinales);
        metodoscomunes.SoloLetras(txtOtrosProblemasSalud);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        txtFechaTrata = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        txtOcupacion = new javax.swing.JTextField();
        txtProfesion = new javax.swing.JTextField();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        txtActividad = new javax.swing.JTextField();
        jLabel94 = new javax.swing.JLabel();
        rbtLeve = new javax.swing.JRadioButton();
        rbtModerada = new javax.swing.JRadioButton();
        rbtIntensa = new javax.swing.JRadioButton();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        txtFrecDepor = new javax.swing.JTextField();
        txtTipoDepor = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtTiempoDepor = new javax.swing.JFormattedTextField();
        jLabel52 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtTratamiento = new javax.swing.JTextArea();
        jLabel43 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtDiagnosticoNutri = new javax.swing.JTextArea();
        jLabel42 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        jLabel44 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        txtUnidadDesayuno = new javax.swing.JTextField();
        txtUnidad12Manana = new javax.swing.JTextField();
        txtUnidadAlmuerzo = new javax.swing.JTextField();
        txtUnidad12Tarde = new javax.swing.JTextField();
        txtUnidadMerienda = new javax.swing.JTextField();
        txtUnidadRefigerio = new javax.swing.JTextField();
        txtUnidadExtra = new javax.swing.JTextField();
        txtMedidaCaseraDesayuno = new javax.swing.JTextField();
        txtMedidaCasera12Manana = new javax.swing.JTextField();
        txtMedidaCaseraAlmuerzo = new javax.swing.JTextField();
        txtMedidaCasera12Tarde = new javax.swing.JTextField();
        txtMedidaCaseraMerienda = new javax.swing.JTextField();
        txtMedidaCaseraRefrigerio = new javax.swing.JTextField();
        txtMedidaCaseraExtra = new javax.swing.JTextField();
        txtGramosDesayuno = new javax.swing.JTextField();
        txtGramos12Manana = new javax.swing.JTextField();
        txtGramosAlmuerzo = new javax.swing.JTextField();
        txtGramos12Tarde = new javax.swing.JTextField();
        txtGramosMerienda = new javax.swing.JTextField();
        txtGramosRefrigerio = new javax.swing.JTextField();
        txtGramosExtra = new javax.swing.JTextField();
        txtAlimentosDesayuno = new javax.swing.JTextField();
        txtAlimentos12Manana = new javax.swing.JTextField();
        txtAlimentosAlmuerzo = new javax.swing.JTextField();
        txtAlimentos12Tarde = new javax.swing.JTextField();
        txtAlimentosMerienda = new javax.swing.JTextField();
        txtAlimentosRefrigerio = new javax.swing.JTextField();
        txtAlimentosExtra = new javax.swing.JTextField();
        jLabel88 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        txtVCTConsumido = new javax.swing.JTextField();
        txtVCTRecomendado = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        txtDesayuno = new javax.swing.JFormattedTextField();
        txtMediaManana = new javax.swing.JFormattedTextField();
        txtAlmuerzo = new javax.swing.JFormattedTextField();
        txtMediaTarde = new javax.swing.JFormattedTextField();
        txtMerienda = new javax.swing.JFormattedTextField();
        txtRefrigerio = new javax.swing.JFormattedTextField();
        txtExtra = new javax.swing.JFormattedTextField();
        jLabel499 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        txtPesoActual = new javax.swing.JTextField();
        txtPesoHabitual = new javax.swing.JTextField();
        txtPesoIdeal = new javax.swing.JTextField();
        txtTalla = new javax.swing.JTextField();
        txtPesoAumento = new javax.swing.JTextField();
        txtDisminucion = new javax.swing.JTextField();
        txtPMuneca = new javax.swing.JTextField();
        txtContexOsea = new javax.swing.JTextField();
        txtCMB = new javax.swing.JTextField();
        txtIMC = new javax.swing.JTextField();
        txtBiceps = new javax.swing.JTextField();
        txtTriceps = new javax.swing.JTextField();
        txtSubescapular = new javax.swing.JTextField();
        txtSuprailiaco = new javax.swing.JTextField();
        txtCintura = new javax.swing.JTextField();
        txtCadera = new javax.swing.JTextField();
        txtCin_Cad = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        txtAlimentosMayorFrecuencia = new javax.swing.JTextField();
        txtAlimentosMasAgrada = new javax.swing.JTextField();
        txtConsumeAlimentosFueraCasa = new javax.swing.JTextField();
        txtAlergiaAlimenticia = new javax.swing.JTextField();
        txtAlimentosDesagradan = new javax.swing.JTextField();
        txtPersonaPreparaSirveAlimentos = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtFaltaApetito = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel81 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        cbxBebidasAlcoholicas = new javax.swing.JComboBox<String>();
        jLabel59 = new javax.swing.JLabel();
        cbxConsumeTabaco = new javax.swing.JComboBox<String>();
        jLabel60 = new javax.swing.JLabel();
        cbxAccesoVoracidad = new javax.swing.JComboBox<String>();
        jLabel61 = new javax.swing.JLabel();
        cbxHorasBulimia = new javax.swing.JComboBox<String>();
        jLabel62 = new javax.swing.JLabel();
        cbxAnsiedadNerviosa = new javax.swing.JComboBox<String>();
        jLabel63 = new javax.swing.JLabel();
        cbxComeDeshoras = new javax.swing.JComboBox<String>();
        jLabel64 = new javax.swing.JLabel();
        cbxApetito = new javax.swing.JComboBox<String>();
        jLabel126 = new javax.swing.JLabel();
        txtSuplemetosVitaminicos = new javax.swing.JTextField();
        jLabel127 = new javax.swing.JLabel();
        txtConsumeSalados = new javax.swing.JTextField();
        jLabel128 = new javax.swing.JLabel();
        txtConsumeFrecuenciaFritaras = new javax.swing.JTextField();
        jLabel129 = new javax.swing.JLabel();
        txtFrecuenciaEnlatados = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel100 = new javax.swing.JLabel();
        txtConsumeFrecuenciaEmbidos = new javax.swing.JTextField();
        jLabel101 = new javax.swing.JLabel();
        txtComeFrutas = new javax.swing.JTextField();
        jLabel102 = new javax.swing.JLabel();
        txtAlimentosCondimentados = new javax.swing.JTextField();
        jLabel103 = new javax.swing.JLabel();
        txtConsumeGaseosas = new javax.swing.JTextField();
        jLabel104 = new javax.swing.JLabel();
        txtProblemasGastrointentinales = new javax.swing.JTextField();
        jLabel109 = new javax.swing.JLabel();
        txtOtrosProblemasSalud = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtExamenLaboratorio = new javax.swing.JTextArea();
        jLabel110 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        btnAtras = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("RegistroCosmetologico"); // NOI18N
        setUndecorated(true);

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel51.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel51.setText("Cedula:");
        jPanel1.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtCedula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCedulaFocusLost(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 170, 30));

        txtFechaTrata.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(txtFechaTrata, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 150, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("Fecha De Ingreso:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 110, 30));

        jLabel57.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel57.setText("Ocupación:");
        jPanel1.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 70, 30));
        jPanel1.add(txtOcupacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, 150, 30));
        jPanel1.add(txtProfesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 170, 30));

        jLabel74.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel74.setText("Profesión:");
        jPanel1.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 60, 30));

        jLabel75.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel75.setText("Actividad:");
        jPanel1.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, -1, 20));
        jPanel1.add(txtActividad, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, 170, 30));

        jLabel94.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel94.setText("Actividad Física:");
        jPanel1.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, 20));

        rbtLeve.setText("Leve");
        jPanel1.add(rbtLeve, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, 30));

        rbtModerada.setText("Moderada");
        jPanel1.add(rbtModerada, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, 30));

        rbtIntensa.setText("Intensa");
        jPanel1.add(rbtIntensa, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, -1, 30));

        jLabel76.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel76.setText("Deportes:");
        jPanel1.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jLabel77.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel77.setText("Tipo:");
        jPanel1.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 40, 30));

        jLabel78.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel78.setText("Tiempo:");
        jPanel1.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 60, 30));

        jLabel79.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel79.setText("Frecuencia:");
        jPanel1.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 70, 30));
        jPanel1.add(txtFrecDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 380, 220, 30));
        jPanel1.add(txtTipoDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 220, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel18.setText("ej: 2017-01-25");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 40, 110, -1));

        try {
            txtTiempoDepor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtTiempoDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 220, 30));

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel52.setPreferredSize(new java.awt.Dimension(650, 427));
        jPanel1.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Actividad Física", jPanel1);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtTratamiento.setColumns(20);
        txtTratamiento.setRows(5);
        jScrollPane4.setViewportView(txtTratamiento);

        jPanel5.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 590, 380));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel43.setToolTipText("");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 450));

        jTabbedPane1.addTab("Tratamiento", jPanel5);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtDiagnosticoNutri.setColumns(20);
        txtDiagnosticoNutri.setRows(5);
        jScrollPane3.setViewportView(txtDiagnosticoNutri);

        jPanel4.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 590, 390));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel4.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 450));

        jTabbedPane1.addTab("Diagnóstico Nutricional", jPanel4);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane2.setViewportView(txtDescripcion);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 600, 390));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel2.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Descripcion", jPanel2);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel56.setText("DESCRIPCION DE HISTORIA ALIMENTICIA");
        jPanel10.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel80.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel80.setText("Extra");
        jPanel10.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, -1));

        jLabel71.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel71.setText("Desayuno");
        jPanel10.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        jLabel82.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel82.setText("1/2 Mañana");
        jPanel10.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel83.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel83.setText("Almuerzo");
        jPanel10.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel84.setText("1/2 Tarde");
        jPanel10.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel85.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel85.setText("Merienda");
        jPanel10.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        jLabel86.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel86.setText("Refrigerio");
        jPanel10.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        jLabel87.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel87.setText("HORAS");
        jPanel10.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, -1, -1));

        jLabel72.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel72.setText("COMIDAS");
        jPanel10.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel55.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel55.setText("UNIDAD");
        jPanel10.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, -1, -1));

        jLabel50.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel50.setText("ALIMENTOS");
        jPanel10.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, -1, -1));

        jLabel73.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel73.setText("MED. CASERAS");
        jPanel10.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 80, -1, -1));
        jPanel10.add(txtUnidadDesayuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 80, -1));
        jPanel10.add(txtUnidad12Manana, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 80, -1));
        jPanel10.add(txtUnidadAlmuerzo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 80, -1));
        jPanel10.add(txtUnidad12Tarde, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 80, -1));
        jPanel10.add(txtUnidadMerienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, 80, -1));
        jPanel10.add(txtUnidadRefigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 80, -1));
        jPanel10.add(txtUnidadExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 290, 80, -1));
        jPanel10.add(txtMedidaCaseraDesayuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 70, -1));
        jPanel10.add(txtMedidaCasera12Manana, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 70, -1));
        jPanel10.add(txtMedidaCaseraAlmuerzo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 170, 70, -1));
        jPanel10.add(txtMedidaCasera12Tarde, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, 70, -1));
        jPanel10.add(txtMedidaCaseraMerienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 70, -1));
        jPanel10.add(txtMedidaCaseraRefrigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 260, 70, -1));
        jPanel10.add(txtMedidaCaseraExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, 70, -1));
        jPanel10.add(txtGramosDesayuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 110, 70, -1));
        jPanel10.add(txtGramos12Manana, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, 70, -1));
        jPanel10.add(txtGramosAlmuerzo, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 170, 70, -1));
        jPanel10.add(txtGramos12Tarde, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 200, 70, -1));
        jPanel10.add(txtGramosMerienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 70, -1));
        jPanel10.add(txtGramosRefrigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, 70, -1));
        jPanel10.add(txtGramosExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 290, 70, -1));
        jPanel10.add(txtAlimentosDesayuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 90, -1));
        jPanel10.add(txtAlimentos12Manana, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, 90, -1));
        jPanel10.add(txtAlimentosAlmuerzo, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 170, 90, -1));
        jPanel10.add(txtAlimentos12Tarde, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 200, 90, -1));
        jPanel10.add(txtAlimentosMerienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 230, 90, -1));
        jPanel10.add(txtAlimentosRefrigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 260, 90, -1));
        jPanel10.add(txtAlimentosExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 290, 90, -1));

        jLabel88.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel88.setText("VCT RECOMENDADOS");
        jPanel10.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel90.setText("VCT CONSUMIDOS");
        jPanel10.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        jLabel89.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel89.setText("TOTAL");
        jPanel10.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));
        jPanel10.add(txtVCTConsumido, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, 90, -1));
        jPanel10.add(txtVCTRecomendado, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 400, 90, -1));

        jLabel91.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel91.setText("GRAMOS");
        jPanel10.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 80, -1, -1));

        try {
            txtDesayuno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtDesayuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 80, -1));

        try {
            txtMediaManana.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtMediaManana, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 80, -1));

        try {
            txtAlmuerzo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtAlmuerzo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 80, -1));

        try {
            txtMediaTarde.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtMediaTarde, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 80, -1));

        try {
            txtMerienda.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtMerienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 80, -1));

        try {
            txtRefrigerio.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtRefrigerio, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 80, -1));

        try {
            txtExtra.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel10.add(txtExtra, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 80, -1));

        jLabel499.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel10.add(jLabel499, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historia Alimenticia", jPanel10);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("Peso Actual:");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel23.setText("Peso Habitual:");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, 20));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel24.setText("Peso Ideal:");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 10, -1, 20));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("Talla:");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, 20));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel26.setText("Cambio de Peso:");
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, 20));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel27.setText("Aumento:");
        jPanel3.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, -1, 20));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel28.setText("Disminución:");
        jPanel3.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, -1, 20));

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel29.setText("Perímetro de la Muñeca:");
        jPanel3.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 30));

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel30.setText("Contextura Osea:");
        jPanel3.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, 30));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel31.setText("Circunferencia Media del Brazo(CMB):");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, 30));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel32.setText("Índice de Masa Corporal(IMC):");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 40));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Pliegues Cutáneos:");
        jPanel3.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel34.setText("Bíceps:");
        jPanel3.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, -1, 20));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel35.setText("Triceps:");
        jPanel3.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, 20));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel36.setText("Subescapular:");
        jPanel3.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, -1, 30));

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel37.setText("Suprailiaco:");
        jPanel3.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, -1, 30));

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel39.setText("Cintura");
        jPanel3.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, -1, 20));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel40.setText("Cadera");
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, -1, 20));

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel41.setText("Cin/Cad:");
        jPanel3.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 340, -1, 20));
        jPanel3.add(txtPesoActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 80, -1));
        jPanel3.add(txtPesoHabitual, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 80, -1));
        jPanel3.add(txtPesoIdeal, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 80, -1));

        txtTalla.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTallaKeyReleased(evt);
            }
        });
        jPanel3.add(txtTalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 90, -1));
        jPanel3.add(txtPesoAumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 70, -1));
        jPanel3.add(txtDisminucion, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 80, -1));
        jPanel3.add(txtPMuneca, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 120, 30));
        jPanel3.add(txtContexOsea, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 100, 30));
        jPanel3.add(txtCMB, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 90, 30));

        txtIMC.setEditable(false);
        jPanel3.add(txtIMC, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 100, 30));
        jPanel3.add(txtBiceps, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 100, 30));
        jPanel3.add(txtTriceps, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 100, 30));
        jPanel3.add(txtSubescapular, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 100, 30));
        jPanel3.add(txtSuprailiaco, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 100, 30));
        jPanel3.add(txtCintura, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 100, 30));
        jPanel3.add(txtCadera, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, 100, 30));
        jPanel3.add(txtCin_Cad, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 340, 100, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("cm");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 30, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("kg/m2");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 40, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("cm");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 260, 30, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("cm");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, 30, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("cm");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 340, 30, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("cm");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 380, 30, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("cm");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 260, 30, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("cm");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 300, 30, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("cm");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 340, 30, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("kg");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, 30, 20));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("kg");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 30, 20));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("kg");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 30, 20));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("kg");
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 10, 30, 20));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("kg");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 30, 20));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("cm");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 30, 20));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("cm");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 30, 30));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Datos Antropométricos", jPanel3);

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel65.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel65.setText("Alimentos que consume con mayor frecuencia");
        jPanel7.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel66.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel66.setText("Alimentos que mas le agradan");
        jPanel7.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, 20));

        jLabel67.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel67.setText("Alimentos que le desagradan");
        jPanel7.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, 20));

        jLabel68.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel68.setText("Intolerancia y/o alergia alimenticia");
        jPanel7.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, 20));

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel69.setText("Persona que prepara  y sirve  la alimentación");
        jPanel7.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        jLabel70.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel70.setText("Consume alimentos fuera de casa");
        jPanel7.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));
        jPanel7.add(txtAlimentosMayorFrecuencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, 30));
        jPanel7.add(txtAlimentosMasAgrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 370, 30));
        jPanel7.add(txtConsumeAlimentosFueraCasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 150, 30));
        jPanel7.add(txtAlergiaAlimenticia, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 370, 30));
        jPanel7.add(txtAlimentosDesagradan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 370, 30));
        jPanel7.add(txtPersonaPreparaSirveAlimentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 370, 30));

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel45.setText("Sufre falta de apetito");
        jPanel7.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));
        jPanel7.add(txtFaltaApetito, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 370, 30));

        jRadioButton1.setText("1v/s");
        jPanel7.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 330, -1, 30));

        jRadioButton2.setText("2v/s");
        jPanel7.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 330, -1, 30));

        jRadioButton3.setText("Esporadico");
        jPanel7.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 330, -1, 30));

        jLabel81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel7.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte I", jPanel7);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel58.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel58.setText("Bebidas alcohólicas");
        jPanel6.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        cbxBebidasAlcoholicas.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Frecuente", "Esporádico", "Nunca" }));
        jPanel6.add(cbxBebidasAlcoholicas, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        jLabel59.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel59.setText("Consume tabaco");
        jPanel6.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 20));

        cbxConsumeTabaco.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Frecuente", "Esporádico", "Nunca" }));
        jPanel6.add(cbxConsumeTabaco, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        jLabel60.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel60.setText("Acceso de voracidad");
        jPanel6.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, 20));

        cbxAccesoVoracidad.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxAccesoVoracidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, -1, -1));

        jLabel61.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel61.setText("Horas de bulimia");
        jPanel6.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, 20));

        cbxHorasBulimia.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        jPanel6.add(cbxHorasBulimia, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, -1, -1));

        jLabel62.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel62.setText("Sufre ansiedad nerviosa");
        jPanel6.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, 20));

        cbxAnsiedadNerviosa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxAnsiedadNerviosa, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, -1));

        jLabel63.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel63.setText("Come a deshoras");
        jPanel6.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, 20));

        cbxComeDeshoras.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxComeDeshoras, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, -1, -1));

        jLabel64.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel64.setText("Apetito");
        jPanel6.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, 20));

        cbxApetito.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bueno", "Malo", "Exagerado" }));
        jPanel6.add(cbxApetito, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, -1, -1));

        jLabel126.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel126.setText("Suplementos vitamínicos");
        jPanel6.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, 20));
        jPanel6.add(txtSuplemetosVitaminicos, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 330, -1));

        jLabel127.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel127.setText("Consume alimentos salados");
        jPanel6.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, 20));
        jPanel6.add(txtConsumeSalados, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 330, -1));

        jLabel128.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel128.setText("Consume con frecuencia frituras");
        jPanel6.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, 20));
        jPanel6.add(txtConsumeFrecuenciaFritaras, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 330, -1));

        jLabel129.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel129.setText("Consume con frecuencia enlatados");
        jPanel6.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, 20));
        jPanel6.add(txtFrecuenciaEnlatados, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 380, 330, -1));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel6.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte II", jPanel6);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel100.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel100.setText("Consume con fecuencia embutidos");
        jPanel9.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));
        jPanel9.add(txtConsumeFrecuenciaEmbidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, -1));

        jLabel101.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel101.setText("Consume frutas");
        jPanel9.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, 20));
        jPanel9.add(txtComeFrutas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 370, -1));

        jLabel102.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel102.setText("Consume alimentos condimentados");
        jPanel9.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 20));
        jPanel9.add(txtAlimentosCondimentados, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 370, -1));

        jLabel103.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel103.setText("Consume gaseosas");
        jPanel9.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, 20));
        jPanel9.add(txtConsumeGaseosas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 370, -1));

        jLabel104.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel104.setText("Problemas gastrointestinales");
        jPanel9.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 20));
        jPanel9.add(txtProblemasGastrointentinales, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 240, -1));

        jLabel109.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel109.setText("Otros problemas de salud");
        jPanel9.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, 20));
        jPanel9.add(txtOtrosProblemasSalud, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 240, -1));

        jLabel53.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel53.setText("Examenes de Laboratorios");
        jPanel9.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, -1, 20));

        txtExamenLaboratorio.setColumns(20);
        txtExamenLaboratorio.setRows(5);
        jScrollPane1.setViewportView(txtExamenLaboratorio);

        jPanel9.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 370, 120));

        jLabel110.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel9.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte III", jPanel9);

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGuardar);

        btnAtras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnAtras.setText("Regresar");
        btnAtras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAtrasMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnAtras);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("tab3");

        getAccessibleContext().setAccessibleName("Registro");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAtrasMouseClicked
        // TODO add your handling code here:
        DatosGenerales dg = new DatosGenerales();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAtrasMouseClicked

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        //Guardar
        PreparedStatement cmd;
        ResultSet rs;
        Conexion.Conectar();
        int cont = 0;
        String variable;

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////TRATAMIENTO////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String tratamiento = txtTratamiento.getText().toUpperCase();
        int conttrata = 0;
        String codptrata = null;
        //SELECT * FROM TIPO_TRATAMIENTO
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
            while (rs.next()) {
                conttrata++;
                codptrata = rs.getString(1);
            }
            if (conttrata == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO TIPO_TRATAMIENTO (COD_TRATA_FACIAL, NOM_TRATA) VALUES ('1', '" + tratamiento + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
                    while (rs.next()) {
                        codptrata = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nTIPO TRATAMIENTO");
                }
            }
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
            conttrata = 0;
            while (rs.next()) {
                codptrata = rs.getString(1);
                conttrata++;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingresó en TipoTratamiento");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////PACIENTE TRATA//////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String fdia = "";
        String fmes = "";
        if (txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
            fdia = "0" + txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH);
        } else {
            fdia = String.valueOf(txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH));
        }

        if ((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1) <= 9) {
            fmes = "0" + ((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1));
        } else {
            fmes = String.valueOf((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1));
        }
        String cedula = "'" + txtCedula.getText() + "'";
        String fechatrata = "'" + txtFechaTrata.getCalendar().get(Calendar.YEAR) + "-" + fmes + "-" + fdia + "'";
        String cedemple = Interfaz.ci;

        System.out.println("fecha: " + fechatrata + "ceduemple: " + cedemple);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////ACTIVIDAD FÍSICA//////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String ocup = txtOcupacion.getText().toUpperCase();
        int contocup = 0;
        String codocup = "";
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_OCUP from OCUPACION where NOM_OCUP = '" + ocup + "'");
            while (rs.next()) {
                codocup = rs.getString(1);
                contocup++;
            }
            if (contocup == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into OCUPACION (NOM_OCUP) VALUES ('" + ocup + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_OCUP from OCUPACION where NOM_OCUP = '" + ocup + "'");
                    while (rs.next()) {
                        codocup = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO OCUPACION");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN OCUPACION");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        int contprof = 0;
        String codprof = "";
        String prof = txtProfesion.getText().toUpperCase();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_PROFESION from PROFESION where NOM_PROFESION = '" + prof + "'");
            while (rs.next()) {
                codprof = rs.getString(1);
                contprof++;
            }
            if (contprof == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into PROFESION (NOM_PROFESION) VALUES ('" + prof + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_PROFESION from PROFESION where NOM_PROFESION = '" + prof + "'");
                    while (rs.next()) {
                        codprof = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO PROFESION");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN PROFESION");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codnivel = "";
        if (rbtLeve.isSelected() == true) {
            codnivel = "1";
        } else if (rbtModerada.isSelected() == true) {
            codnivel = "2";
        } else if (rbtIntensa.isSelected() == true) {
            codnivel = "3";
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String tipodepor = txtTipoDepor.getText().toUpperCase();
        String tiempodepor = txtTiempoDepor.getText();
        String fdepor = txtFrecDepor.getText().toUpperCase();
        String coddepor = "";
        //SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = 'FUTBOL' AND D.TIEMPO_DEPORTE = '01:00' AND D.FRECUENCIA = 'INTENSA';
        int contdepor = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = '" + tipodepor + "' AND D.TIEMPO_DEPORTE = '" + tiempodepor + "' AND D.FRECUENCIA = '" + fdepor + "'");
            while (rs.next()) {
                coddepor = rs.getString(1);
                contdepor++;
            }
            if (contdepor == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DEPORTES (TIPO_DEPORTE, TIEMPO_DEPORTE, FRECUENCIA) VALUES ('" + tipodepor + "', '" + tiempodepor + "', '" + fdepor + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = '" + tipodepor + "' AND D.TIEMPO_DEPORTE = '" + tiempodepor + "' AND D.FRECUENCIA = '" + fdepor + "'");
                    while (rs.next()) {
                        coddepor = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO DEPORTE");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES DEPORTE");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codact = "";
        String acti = txtActividad.getText().toUpperCase();
        int contacti = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_ACT from ACTIVIDAD where NOM_ACT = '" + acti + "'");
            while (rs.next()) {
                codact = rs.getString(1);
                contacti++;
            }
            if (contacti == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into ACTIVIDAD (NOM_ACT) VALUES ('" + acti + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_ACT FROM ACTIVIDAD WHERE NOM_ACT = '" + acti + "'");
                    while (rs.next()) {
                        codact = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO ACTIVIDAD");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN ACTIVIDAD");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PACIENTE_TRATAMIENTO "
                    + "(FECHA_TRATA, CEDULA, COD_TRATAMIENTO, CED_EMPLEADO) "
                    + "VALUES (" + fechatrata + ", " + cedula + ", '" + codptrata + "', '" + cedemple + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Paciente Trata");
        }
        System.out.println("Fin ingreso");
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////ACTIVIDAD FÍSICA/////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from ACTIVIDAD_FISICA");
            while (rs.next()) {
                contocup++;
            }
            cmd = ventanas.Conexion.link.prepareStatement("insert into ACTIVIDAD_FISICA "
                    + "(COD_NIV, COD_OCUP, COD_PROFESION, COD_DEPORTE, COD_ACT, FECHA_TRATA, CEDULA, COD_TRATAMIENTO)"
                    + " VALUES ('" + codnivel + "', '" + codocup + "', '" + codprof + "', '" + coddepor
                    + "', '" + codact + "', " + fechatrata + ", " + cedula + ", '" + codptrata + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNO SE INGRESO ACTIVIDAD_FISICA");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////DIAGNOSTICO////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String diagnostico = txtDiagnosticoNutri.getText().toUpperCase();
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DIAGNOSTICO (DESC_DIAGNOSTICO) VALUES ('" + diagnostico + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\n\tNo se ingreso Diagnostico");
        }
        String descripcion = txtDiagnosticoNutri.getText().toUpperCase();
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DESCRIPCION (DESCRIPCION) VALUES ('" + descripcion + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\n\tNo se ingreso Descripcion");
        }

        //////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////HISTORIA CLINICA (OJO)//////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        String codhisto = "";

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTORIA "
                    + "FROM HISTORIA_CLINICA WHERE CEDULA = " + cedula);
            while (rs.next()) {
                cont++;
            }
            if (cont == 0) {
                rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT * FROM HISTORIA_CLINICA");
                while (rs.next()) {
                    cont++;
                }
                cont += 1;
                codhisto = String.valueOf(cont);
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_CLINICA "
                            + "(COD_HISTORIA, FECHA_TRATA, CEDULA, COD_TRATAMIENTO) "
                            + "VALUES ('" + codhisto + "', " + fechatrata
                            + ", " + cedula + ", '" + codptrata + "')");
                    cmd.execute();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso HISTORIA CLINICA");
                }
            } else {
                rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT HC.COD_HISTORIA FROM HISTORIA_CLINICA HC WHERE HC.CEDULA = " + cedula);
                while (rs.next()) {
                    codhisto = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nES OTRO PRO DE HC");
        }
        cont = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////DATOS DIETETICOS////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        //0 Falso
        //1 Verdadero
        String codhistodiet = "";
        //String codcondualifuecasa = "";//Está abajo
        int codbebidas = 0;//cbx-
        String codcontabaco = "";//cbx-
        String codapetito = "";//cbx-
        int codproblema =0;
        int codotroproblemas = 0;
        String alimafrec = txtAlimentosMayorFrecuencia.getText().toUpperCase();
        String alimasagrada = txtAlimentosMasAgrada.getText().toUpperCase();
        String alidesagradan = txtAlimentosDesagradan.getText().toUpperCase();
        String alergia = txtAlergiaAlimenticia.getText().toUpperCase();
        String persirali = txtPersonaPreparaSirveAlimentos.getText().toUpperCase();
        String consalifuera = txtConsumeAlimentosFueraCasa.getText().toUpperCase();
        String voracidad = "";//cbx
        String horbulimia = "0";//cbx
        String sufreansiedad = "";//cbx
        String sufrefalta = txtFaltaApetito.getText().toUpperCase();
        String comedeshora = "";//cbx
        String suplevita = txtSuplemetosVitaminicos.getText().toUpperCase();
        String consualisal = txtConsumeSalados.getText().toUpperCase();
        String consufrecfri = txtConsumeFrecuenciaFritaras.getText().toUpperCase();
        String consufreclata = txtFrecuenciaEnlatados.getText().toUpperCase();
        String consufrecembu = txtConsumeFrecuenciaEmbidos.getText().toUpperCase();
        String consufruta = txtComeFrutas.getText().toUpperCase();
        String consualicondi = txtAlimentosCondimentados.getText().toUpperCase();
        String consugaseosa = txtConsumeGaseosas.getText().toUpperCase();

        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxBebidasAlcoholicas.getSelectedItem();
        if ("Frecuente".equals(variable)) {
            codbebidas = 1;
        }
        if ("Esporádico".equals(variable)) {
            codbebidas = 2;
        }
        if ("Nunca".equals(variable)) {
            codbebidas = 3;
        }
        System.out.println(codbebidas + " codigo bebidas");
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxConsumeTabaco.getSelectedItem();
        if ("Frecuente".equals(variable)) {
            codcontabaco = "1";
        }
        if ("Esporádico".equals(variable)) {
            codcontabaco = "2";
        }
        if ("Nunca".equals(variable)) {
            codcontabaco = "3";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxApetito.getSelectedItem();
        if ("Bueno".equals(variable)) {
            codapetito = "1";
        }
        if ("Malo".equals(variable)) {
            codapetito = "2";
        }
        if ("Exagerado".equals(variable)) {
            codapetito = "3";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxAccesoVoracidad.getSelectedItem();
        if ("Si".equals(variable)) {
            voracidad = "1";
        }
        if ("No".equals(variable)) {
            voracidad = "0";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxHorasBulimia.getSelectedItem();
        if ("1".equals(variable)) {
            horbulimia = "1";
        }
        if ("2".equals(variable)) {
            horbulimia = "2";
        }
        if ("3".equals(variable)) {
            horbulimia = "3";
        }
        if ("4".equals(variable)) {
            horbulimia = "4";
        }
        if ("5".equals(variable)) {
            horbulimia = "5";
        }
        if ("6".equals(variable)) {
            horbulimia = "6";
        }
        if ("7".equals(variable)) {
            horbulimia = "7";
        }
        if ("8".equals(variable)) {
            horbulimia = "8";
        }
        if ("9".equals(variable)) {
            horbulimia = "9";
        }
        if ("10".equals(variable)) {
            horbulimia = "10";
        }
        if ("11".equals(variable)) {
            horbulimia = "11";
        }
        if ("12".equals(variable)) {
            horbulimia = "12";
        }
        if ("0".equals(variable)) {
            horbulimia = "0";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxAnsiedadNerviosa.getSelectedItem();
        if ("Si".equals(variable)) {
            sufreansiedad = "Si";
        }
        if ("No".equals(variable)) {
            sufreansiedad = "No";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxComeDeshoras.getSelectedItem();
        if ("Si".equals(variable)) {
            comedeshora = "Si";
        }
        if ("No".equals(variable)) {
            comedeshora = "No";
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       
        if (jRadioButton1.isSelected() == true) {
            consalifuera = txtConsumeAlimentosFueraCasa.getText().toUpperCase() + " 1 v/s";
        } else if (jRadioButton1.isSelected() == true) {
            consalifuera = txtConsumeAlimentosFueraCasa.getText().toUpperCase() + " 2 v/s";
        } else if (jRadioButton1.isSelected() == true) {
            consalifuera = txtConsumeAlimentosFueraCasa.getText().toUpperCase() + " Esporadico";
        }
        int consuefueca=0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_PROBLEMA FROM PROBLEMAS_GASTROINTESTINALES WHERE NOM_PROBLEMA = '" + txtProblemasGastrointentinales.getText().toUpperCase() + "'");
            while (rs.next()) {
                cont++;
            }
            cont+=1;
                    
                    codproblema=cont;
                    cont=0;
            if (cont == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PROBLEMAS_GASTROINTESTINALES (NOM_PROBLEMA) VALUES ('" + txtProblemasGastrointentinales.getText().toUpperCase() + "')");
                    cmd.execute();//INGRESO A PROBLIMAS GASTROINTESTINALES
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_PROBLEMA FROM PROBLEMAS_GASTROINTESTINALES WHERE NOM_PROBLEMA = '" + txtProblemasGastrointentinales.getText().toUpperCase() + "'");
                    while (rs.next()) {
                        codproblema = Integer.parseInt(rs.getString(1));
                    }
                    cont = 0;
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_CONSU_ALI_FUE_CA FROM CONSUME_ALIMENTOS_FUERA_DE_CASA WHERE DES_CON_ALI = '" + consalifuera + "'");
                    while (rs.next()) {
                        cont++;
                    }
                    cont+=1;
                    
                    consuefueca=cont;
                    cont=0;
                    
                    if (cont == 0) {
                        cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO CONSUME_ALIMENTOS_FUERA_DE_CASA (DES_CON_ALI) VALUES ('" + consalifuera + "')");
                        cmd.execute();
                        rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_CONSU_ALI_FUE_CA FROM CONSUME_ALIMENTOS_FUERA_DE_CASA WHERE DES_CON_ALI = '" + consalifuera + "'");
                        while (rs.next()) {
                            consuefueca = Integer.parseInt(rs.getString(1));
                        }
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Consume Alimentos Fuera de Casa y Problemas gastro");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "Fuera de casa y Gatrointestinales");
        }
        cont = 0;
        System.out.println(consuefueca + " " + consalifuera);
        //////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_OTRO FROM OTROS_PROBLEMAS WHERE NOMBRE_OTRO_PROBLEMA = '" + txtOtrosProblemasSalud.getText().toUpperCase() + "'");
            while (rs.next()) {
                cont++;
            }
            cont+=1;       
            codotroproblemas=cont;
            cont=0;
            if (cont == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OTROS_PROBLEMAS (NOMBRE_OTRO_PROBLEMA) VALUES ('" + txtOtrosProblemasSalud.getText().toUpperCase() + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_OTRO FROM OTROS_PROBLEMAS WHERE NOMBRE_OTRO_PROBLEMA = '" + txtOtrosProblemasSalud.getText().toUpperCase() + "'");
                    while (rs.next()) {
                        codotroproblemas = Integer.parseInt(rs.getString(1));
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Otros Problemas");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        cont = 0;
        //////////////////////////////////////////////////////////////////////////////////////
        String exam = txtExamenLaboratorio.getText();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTORIA_DIETETICA FROM HISTORIA_DIETETICA");
            while (rs.next()) {
                cont++;
            }
            codhistodiet = String.valueOf(cont + 1);
            try {
                cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_DIETETICA "
                        + "VALUES ('" + codhistodiet + "', '" + consuefueca + "', '" + codbebidas + "', '" + codcontabaco
                        + "', '" + codapetito + "', '" + codproblema + "', '" + codotroproblemas
                        + "', '" + codhisto + "',  " + fechatrata + " , '" + alimafrec + "', '" + alimasagrada
                        + "', '" + alidesagradan + "', '" + alergia + "', '" + persirali + "', '" + consalifuera
                        + "', '" + voracidad + "', '" + horbulimia + "', '" + sufreansiedad + "', '" + sufrefalta
                        + "', '" + comedeshora + "', '" + suplevita + "', '" + consualisal + "', '" + consufrecfri
                        + "', '" + consufreclata + "', '" + consufrecembu + "', '" + consufruta + "', '" + consualicondi
                        + "', '" + consugaseosa + "', '" + exam + "')");
                cmd.execute();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e + "\nNO Datos Dieteticos");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nES Datos Dieteticos");
        }
        cont = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////DATOS ANTROPOMETRICOS///////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codantro = "";
        String pesoactual = txtPesoActual.getText();
        String pesohabitual = txtPesoHabitual.getText();
        String pesoideal = txtPesoIdeal.getText();
        String talla = txtTalla.getText();
        String pesoaumento = txtPesoAumento.getText();
        String pesodisminucion = txtDisminucion.getText();
        String permuneca = txtPMuneca.getText();
        String contexosea = txtContexOsea.getText();
        String cmb = txtCMB.getText();
        String imc = txtIMC.getText();
        String biceps = txtBiceps.getText();
        String triceps = txtTriceps.getText();
        String subescapular = txtSubescapular.getText();
        String suprailiaco = txtSuprailiaco.getText();
        String cintura = txtCintura.getText();
        String cadera = txtCadera.getText();
        String cin_cad = txtCin_Cad.getText();
        cont = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_ANTROPOMETRICO FROM DATOS_ANTROPOMETRICOS");
            while (rs.next()) {
                cont++;
            }
            codantro = String.valueOf(cont + 1);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se hizo la consulta de DA");
        }
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DATOS_ANTROPOMETRICOS VALUES ('" + codantro + "', '" + pesoactual
                    + "', '" + pesohabitual + "', '" + pesoideal + "', '" + talla + "', '" + pesoaumento + "', '" + pesodisminucion
                    + "', '" + permuneca + "', '" + contexosea + "', '" + cmb + "', '" + imc + "', '" + biceps + "', '" + triceps
                    + "', '" + subescapular + "', '" + suprailiaco + "', '" + cintura + "', '" + cadera + "', '" + cin_cad + "')");

            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNO Datos Antropometricos");
        }
        cont = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String coddiag = "";
        String coddesc = "";
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_DIAGNOSTICO FROM DIAGNOSTICO WHERE DESC_DIAGNOSTICO = '" + txtDiagnosticoNutri.getText().toUpperCase() + "'");
            while (rs.next()) {
                coddiag = rs.getString(1);
            }
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_DESCRIPCION FROM DESCRIPCION DC WHERE DC.DESCRIPCION = '" + txtDescripcion.getText().toUpperCase() + "'");
            while (rs.next()) {
                coddesc = rs.getString(1);
            }
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OBTIENE VALUES "
                    + "(" + codhisto + ", " + coddiag + ", '1', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingresó en Obtiene");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        cont = 0;
        String codhistoali = "";
        String deschistoali
                = "DESAYUNO : " + txtDesayuno.getText().toUpperCase() + " ; " + txtUnidadDesayuno.getText().toUpperCase() + " ; "
                + txtMedidaCaseraDesayuno.getText().toUpperCase() + " ; " + txtUnidadDesayuno.getText().toUpperCase() + " ; "
                + txtAlimentosDesayuno.getText().toUpperCase() + "\n"
                + "1/2 MANANA : " + txtMediaManana.getText().toUpperCase() + " ; " + txtUnidad12Manana.getText().toUpperCase() + " ; "
                + txtMedidaCasera12Manana.getText().toUpperCase() + " ; " + txtUnidad12Manana.getText().toUpperCase() + " ; "
                + txtAlimentos12Manana.getText().toUpperCase() + "\n"
                + "ALMUERZO : " + txtAlmuerzo.getText().toUpperCase() + " ; " + txtUnidadAlmuerzo.getText().toUpperCase() + " ; "
                + txtMedidaCaseraAlmuerzo.getText().toUpperCase() + " ; " + txtUnidadAlmuerzo.getText().toUpperCase() + " ; "
                + txtAlimentosAlmuerzo.getText().toUpperCase() + "\n"
                + "1/2 TARDE : " + txtMediaTarde.getText().toUpperCase() + " ; " + txtUnidad12Tarde.getText().toUpperCase() + " ; "
                + txtMedidaCasera12Tarde.getText().toUpperCase() + " ; " + txtUnidad12Tarde.getText().toUpperCase() + " ; "
                + txtAlimentos12Tarde.getText().toUpperCase() + "\n"
                + "MERIENDA : " + txtMerienda.getText().toUpperCase() + " ; " + txtUnidadMerienda.getText().toUpperCase() + " ; "
                + txtMedidaCaseraMerienda.getText().toUpperCase() + " ; " + txtUnidadMerienda.getText().toUpperCase() + " ; "
                + txtAlimentosMerienda.getText().toUpperCase() + "\n"
                + "REFRIGERIO : " + txtRefrigerio.getText().toUpperCase() + " ; " + txtUnidadRefigerio.getText().toUpperCase() + " ; "
                + txtMedidaCaseraRefrigerio.getText().toUpperCase() + " ; " + txtUnidadRefigerio.getText().toUpperCase() + " ; "
                + txtAlimentosRefrigerio.getText().toUpperCase() + "\n"
                + "EXTRAS : " + txtExtra.getText().toUpperCase() + " ; " + txtUnidadExtra.getText().toUpperCase() + " ; "
                + txtMedidaCaseraExtra.getText().toUpperCase() + " ; " + txtUnidadExtra.getText().toUpperCase() + " ; "
                + txtAlimentosExtra.getText().toUpperCase() + "\n"
                + "\nTOTAL\nVCT CONSUMIDO :" + txtVCTConsumido.getText().toUpperCase()
                + "\nVCT RECOMENDADO : " + txtVCTRecomendado.getText().toUpperCase();

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTO_ALIMENTICIA FROM HISTORIA_ALIMENTICIA");
            while (rs.next()) {
                cont++;
            }
            cont += 1;
            codhistoali = String.valueOf(cont);
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_ALIMENTICIA VALUES "
                    + "('" + codhistoali + "', '" + deschistoali + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo ingrsó en histo alimenticia");
        }
        cont = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO REALIZADO VALUES "
                    + "('" + codhistoali + "', '1', '" + codhisto + "', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo ingreso en realizado");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO POSEE VALUES "
                    + "('" + codantro + "', " + fechatrata + ", " + cedula + ", '" + codptrata + "', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "NO POSEE\n" + e);
        }///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OBTIENE VALUES "
                    + "('" + codhisto + "', '" + coddiag + "', '" + coddesc + "', " + fechatrata + ")");
            cmd.execute();
            System.out.println("si obtiene");
        } catch (SQLException e) {
            System.out.println("NO OBTIENE\n" + e);
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////

//INSERT INTO PACIENTE_TRATAMIENTO (FECHA_TRATA, CEDULA, COD_TRATAMIENTO, CED_EMPLEADO) VALUES ('2016-12-12', '0802502948', '1', '1020304050');
        this.setVisible(false);
        DatosGenerales to = new DatosGenerales();
        to.setVisible(true);


    }//GEN-LAST:event_btnGuardarMouseClicked

    private void txtCedulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCedulaFocusLost
        // COMPROBAMOS QUE EL PACIENTE EXISTA
        ResultSet rs;
        DatosGenerales rc = new DatosGenerales();
        String cedula = "'" + txtCedula.getText() + "'";
        int count = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select CEDULA from PACIENTE where CEDULA = " + cedula);
            while (rs.next()) {
                count++;
            }
            if (count == 0) {
                JOptionPane.showMessageDialog(null, "El cliente no está registrado.\nPor favor registrelo primero");
                //rc.show();
                this.setVisible(false);
                rc.setVisible(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        cecliente = txtCedula.getText();
    }//GEN-LAST:event_txtCedulaFocusLost

    private void txtTallaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTallaKeyReleased
        // TODO add your handling code here:
        double pesokg = Double.parseDouble(txtPesoActual.getText());
        double tallam = Double.parseDouble(txtTalla.getText());
        double resultado = 0;
        if (txtTalla.getText().isEmpty() == true) {
            tallam = 0;
        }
        tallam = tallam / 100;
        try {
            resultado = pesokg / Math.pow(tallam, 2);
        } catch (ArithmeticException e) {
            System.out.println("No puede dividir para 0");
        }
        resultado = Math.floor(resultado * 100) / 100;
        System.out.println(resultado);
        txtIMC.setText(String.valueOf(resultado));
    }//GEN-LAST:event_txtTallaKeyReleased

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroNutricional.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnAtras;
    private javax.swing.JMenu btnGuardar;
    private javax.swing.JComboBox<String> cbxAccesoVoracidad;
    private javax.swing.JComboBox<String> cbxAnsiedadNerviosa;
    private javax.swing.JComboBox<String> cbxApetito;
    private javax.swing.JComboBox<String> cbxBebidasAlcoholicas;
    private javax.swing.JComboBox<String> cbxComeDeshoras;
    private javax.swing.JComboBox<String> cbxConsumeTabaco;
    private javax.swing.JComboBox<String> cbxHorasBulimia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel499;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rbtIntensa;
    private javax.swing.JRadioButton rbtLeve;
    private javax.swing.JRadioButton rbtModerada;
    private javax.swing.JTextField txtActividad;
    private javax.swing.JTextField txtAlergiaAlimenticia;
    private javax.swing.JTextField txtAlimentos12Manana;
    private javax.swing.JTextField txtAlimentos12Tarde;
    private javax.swing.JTextField txtAlimentosAlmuerzo;
    private javax.swing.JTextField txtAlimentosCondimentados;
    private javax.swing.JTextField txtAlimentosDesagradan;
    private javax.swing.JTextField txtAlimentosDesayuno;
    private javax.swing.JTextField txtAlimentosExtra;
    private javax.swing.JTextField txtAlimentosMasAgrada;
    private javax.swing.JTextField txtAlimentosMayorFrecuencia;
    private javax.swing.JTextField txtAlimentosMerienda;
    private javax.swing.JTextField txtAlimentosRefrigerio;
    private javax.swing.JFormattedTextField txtAlmuerzo;
    private javax.swing.JTextField txtBiceps;
    private javax.swing.JTextField txtCMB;
    private javax.swing.JTextField txtCadera;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCin_Cad;
    private javax.swing.JTextField txtCintura;
    private javax.swing.JTextField txtComeFrutas;
    private javax.swing.JTextField txtConsumeAlimentosFueraCasa;
    private javax.swing.JTextField txtConsumeFrecuenciaEmbidos;
    private javax.swing.JTextField txtConsumeFrecuenciaFritaras;
    private javax.swing.JTextField txtConsumeGaseosas;
    private javax.swing.JTextField txtConsumeSalados;
    private javax.swing.JTextField txtContexOsea;
    private javax.swing.JFormattedTextField txtDesayuno;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextArea txtDiagnosticoNutri;
    private javax.swing.JTextField txtDisminucion;
    private javax.swing.JTextArea txtExamenLaboratorio;
    private javax.swing.JFormattedTextField txtExtra;
    private javax.swing.JTextField txtFaltaApetito;
    private com.toedter.calendar.JDateChooser txtFechaTrata;
    private javax.swing.JTextField txtFrecDepor;
    private javax.swing.JTextField txtFrecuenciaEnlatados;
    private javax.swing.JTextField txtGramos12Manana;
    private javax.swing.JTextField txtGramos12Tarde;
    private javax.swing.JTextField txtGramosAlmuerzo;
    private javax.swing.JTextField txtGramosDesayuno;
    private javax.swing.JTextField txtGramosExtra;
    private javax.swing.JTextField txtGramosMerienda;
    private javax.swing.JTextField txtGramosRefrigerio;
    private javax.swing.JTextField txtIMC;
    private javax.swing.JFormattedTextField txtMediaManana;
    private javax.swing.JFormattedTextField txtMediaTarde;
    private javax.swing.JTextField txtMedidaCasera12Manana;
    private javax.swing.JTextField txtMedidaCasera12Tarde;
    private javax.swing.JTextField txtMedidaCaseraAlmuerzo;
    private javax.swing.JTextField txtMedidaCaseraDesayuno;
    private javax.swing.JTextField txtMedidaCaseraExtra;
    private javax.swing.JTextField txtMedidaCaseraMerienda;
    private javax.swing.JTextField txtMedidaCaseraRefrigerio;
    private javax.swing.JFormattedTextField txtMerienda;
    private javax.swing.JTextField txtOcupacion;
    private javax.swing.JTextField txtOtrosProblemasSalud;
    private javax.swing.JTextField txtPMuneca;
    private javax.swing.JTextField txtPersonaPreparaSirveAlimentos;
    private javax.swing.JTextField txtPesoActual;
    private javax.swing.JTextField txtPesoAumento;
    private javax.swing.JTextField txtPesoHabitual;
    private javax.swing.JTextField txtPesoIdeal;
    private javax.swing.JTextField txtProblemasGastrointentinales;
    private javax.swing.JTextField txtProfesion;
    private javax.swing.JFormattedTextField txtRefrigerio;
    private javax.swing.JTextField txtSubescapular;
    private javax.swing.JTextField txtSuplemetosVitaminicos;
    private javax.swing.JTextField txtSuprailiaco;
    private javax.swing.JTextField txtTalla;
    private javax.swing.JFormattedTextField txtTiempoDepor;
    private javax.swing.JTextField txtTipoDepor;
    private javax.swing.JTextArea txtTratamiento;
    private javax.swing.JTextField txtTriceps;
    private javax.swing.JTextField txtUnidad12Manana;
    private javax.swing.JTextField txtUnidad12Tarde;
    private javax.swing.JTextField txtUnidadAlmuerzo;
    private javax.swing.JTextField txtUnidadDesayuno;
    private javax.swing.JTextField txtUnidadExtra;
    private javax.swing.JTextField txtUnidadMerienda;
    private javax.swing.JTextField txtUnidadRefigerio;
    private javax.swing.JTextField txtVCTConsumido;
    private javax.swing.JTextField txtVCTRecomendado;
    // End of variables declaration//GEN-END:variables
}
