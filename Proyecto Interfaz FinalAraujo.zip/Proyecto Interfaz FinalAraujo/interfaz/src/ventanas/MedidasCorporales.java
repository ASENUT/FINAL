package ventanas;

import java.awt.Graphics;
import java.awt.PrintJob;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MedidasCorporales extends javax.swing.JFrame {

    static String cedula = "";
    static String nombre = "";
    static String fecha = "";
    static String tratamiento = "";

    public MedidasCorporales() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtCedula = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbxTratamientos = new javax.swing.JComboBox();
        jLabel31 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnImprimir = new javax.swing.JMenu();
        btnRegresar = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCedula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCedulaFocusLost(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 100, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Medidas de:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("CI :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Fecha", "Tratamiento", "Busto", "Cadera", "Cintura", "EntrePierna D", "Entrepierna I", "Estómago", "Muslo D", "Muslo I"
            }
        ));
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 770, 300));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Fecha:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 160, 20));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 120, 20));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Tratamiento:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, -1, -1));

        cbxTratamientos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxTratamientos.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTratamientosItemStateChanged(evt);
            }
        });
        jPanel1.add(cbxTratamientos, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel31.setPreferredSize(new java.awt.Dimension(650, 427));
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 430));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 430));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        btnImprimir.setText("Imprirmir");
        btnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnImprimirMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnImprimir);

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnRegresar);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresarMouseClicked
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresarMouseClicked

    private void btnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImprimirMouseClicked
        // TODO add your handling code here:
        PrintJob imprime = getToolkit().getPrintJob(this, evt.getClass().getName(), null);
        if (imprime != null) {
            Graphics pag = imprime.getGraphics();
            if (pag != null) {
                paint(pag); //pinta todo los objetos de la ventana mostrada
                pag.dispose();
            }
        } else {
            //JOptionPane.showMessageDialog(null, “no se imprimo nada”, “imprimir”, JOptionPane.INFORMATION_MESSAGE );
            imprime.end();
        }
        imprime.end();
    }//GEN-LAST:event_btnImprimirMouseClicked

    private void txtCedulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCedulaFocusLost
        // TODO add your handling code here:
        ResultSet rs;
        String nombre = "";
        String ced = "";

        cargarlista();

        ced = txtCedula.getText();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select concat(APE_PAC, ' ', NOM_PAC) from PACIENTE WHERE CEDULA = '" + ced + "'");
            while (rs.next()) {
                nombre = rs.getString(1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }

        jLabel4.setText(nombre);
        System.out.println(ced);

        this.nombre = nombre;
        this.fecha = fecha;
        this.cedula = ced;
    }//GEN-LAST:event_txtCedulaFocusLost

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        ResultSet rs;
        String nombre = "";
        String ced = "";

        cargarlista();
        ced = HistorialNutricional.cedulantri;
        txtCedula.setText(ced);
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select concat(APE_PAC, ' ', NOM_PAC) from PACIENTE WHERE CEDULA = '" + ced + "'");
            while (rs.next()) {
                nombre = rs.getString(1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }

        jLabel4.setText(nombre);
        System.out.println(ced);
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        cbxTratamientos.removeAllItems();
        Calendar calen = new GregorianCalendar();
        int dia, mes, anio;
        anio = calen.get(Calendar.YEAR);
        mes = calen.get(Calendar.MONTH) + 1;
        dia = calen.get(Calendar.DAY_OF_MONTH);
        String fecha = anio + "-" + mes + "-" + dia;
        jLabel6.setText(fecha);

        this.nombre = nombre;
        this.fecha = fecha;
        this.cedula = ced;
    }//GEN-LAST:event_formWindowActivated

    private void cbxTratamientosItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTratamientosItemStateChanged
        // TODO add your handling code here:
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        String ced = txtCedula.getText();

        String nomtrata = "";
        String codptrata = "";//OJO HACER CONSULTA DEL TRATAMIENTO
        nomtrata = (String) cbxTratamientos.getSelectedItem();
        System.out.println(nomtrata);
        try {
            if (!nomtrata.equalsIgnoreCase(null)) {
                this.tratamiento = nomtrata;
                try {
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + nomtrata + "'");
                    while (rs.next()) {
                        codptrata = rs.getString(1);
                    }
                    System.out.println(codptrata);
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "No se encotró el tratamiento");
                }

                try {
                    dtm.addColumn("Fecha");
                    dtm.addColumn("Tratamiento");
                    dtm.addColumn("Busto");
                    dtm.addColumn("Cadera");
                    dtm.addColumn("Cintura");
                    dtm.addColumn("EntrePierna D");
                    dtm.addColumn("EntrePierna I");
                    dtm.addColumn("Estómago");
                    dtm.addColumn("Muslo D");
                    dtm.addColumn("Muslo I");
                    /*
                     MD.FECHA_MEDICION, TT.NOM_TRATA, MD.BUSTO, 
                     MD.CADERAS, MD.CINTURA, MD.ENTREPIERNA_DER, 
                     MD.ENTREPIERNA_IZ, MD.ESTOMAGO, MD.MUSLO_DER, MD.MUSLO_IZ*/
                    rs = ventanas.Conexion.link.createStatement().executeQuery("select distinct MD.FECHA_MEDICION, TT.NOM_TRATA, MD.BUSTO, MD.CADERAS, MD.CINTURA, MD.ENTREPIERNA_DER, MD.ENTREPIERNA_IZ, MD.ESTOMAGO, MD.MUSLO_DER, MD.MUSLO_IZ from MEDIDAS_CORPORALES MD, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT where  MD.CEDULA = PT.CEDULA AND MD.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND MD.CEDULA = '" + ced + "' AND MD.COD_TRATAMIENTO = '" + codptrata + "'");
                    while (rs.next()) {
                        dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                            rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
                    }
                    jTable1.setModel(dtm);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }
            }
        } catch (Exception e) {
            System.out.println("excepcion de combo box");
        }
    }//GEN-LAST:event_cbxTratamientosItemStateChanged

    private void cargarlista() {
        // TODO Auto-generated method stub
        ResultSet rs = null;
        //cbxTratamientos.addItem("Seleccione");
        try {
            Conexion.Conectar();
            rs = ventanas.Conexion.link.createStatement().executeQuery("select TT.NOM_TRATA from PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT WHERE PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CEDULA = '" + txtCedula.getText() + "';");
            while (rs.next()) {
                String tmpStrObtenido = rs.getString(1);
                cbxTratamientos.addItem(tmpStrObtenido);
            }
            Conexion.Close();
            Conexion.Conectar();
        } catch (Exception e) {
            System.out.println("ERROR: falla al cargar los trataminetos");
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MedidasCorporales.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MedidasCorporales().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnImprimir;
    private javax.swing.JMenu btnRegresar;
    private javax.swing.JComboBox cbxTratamientos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtCedula;
    // End of variables declaration//GEN-END:variables
}
