/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import Datos.DCitas;
import Logico.LCitas;
import java.awt.TextField;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alumnos
 */
public class Horarios extends javax.swing.JFrame {
    LCitas citas= new LCitas();
    DCitas d=new DCitas();
    Logico.Conexion c = new Logico.Conexion();
    PreparedStatement cmd;  
    ResultSet rs;
    String HoraCita;
    String FechaCita;
    String Cliente;
    String TipoCita;
    String accion ="";//Para saber que accion realizar, guardar, eliminar, editar
    public Horarios() {
        PreparedStatement cmd;  
        ResultSet rs;
        initComponents();
        this.setLocationRelativeTo(null);
        sacartexto();
        
    }

    void CargarTabla(){
        try {
            DefaultTableModel modelo;
            LCitas func=new LCitas();
            modelo =func.CargarTabla();
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    void Mostrar(String buscar){
        try {
            DefaultTableModel modelo;
            LCitas func=new LCitas();
            modelo =func.mostrar(buscar);
            Lista_Cita.setModel(modelo);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void sacartexto(){
        Cliente=d.getCliente();
        FechaCita=d.getFechaCita();
        HoraCita=d.getHoraCita();
        TipoCita=d.getTipoCita();
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Lista_Cita = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        txtfBuscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        btnEliminar = new javax.swing.JMenu();
        btnEditar = new javax.swing.JMenu();
        btnActualizar = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Lista_Cita.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "COD Horario", "Hora Cita", "Fecha Cita"
            }
        ));
        jScrollPane1.setViewportView(Lista_Cita);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 620, 150));

        btnBuscar.setText("Buscar");
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));
        getContentPane().add(txtfBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 210, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 230));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        jMenu4.setText("Imprirmir");
        jMenuBar1.add(jMenu4);

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Delete.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEliminar);

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Edit.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnEditar);

        btnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        btnActualizar.setText("Actualizar");
        btnActualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnActualizarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnActualizar);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        Citas c = new Citas();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu5MouseClicked

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        int Confirmar=JOptionPane.showConfirmDialog(rootPane, "Esta seguro que desea eliminar","Confirmar",2);//Si confirma eliminar es el 1
        if (Confirmar==0) {
            int i=(int)Lista_Cita.getSelectedRow();
            int j=(int)Lista_Cita.getSelectedColumn();
            int COD_HORARIO=(int)Lista_Cita.getValueAt(i, j);
            d.setCOD_Horario(COD_HORARIO);
            citas.elminarHorario(d);
            
        }
    }//GEN-LAST:event_btnEliminarMouseClicked
    
    private void btnEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarMouseClicked
        // TODO add your handling code here:
        int COD_horario=0;
        String Hora_cita="";
        String Fecha_cita="";
        for(int x=0;;x++){
            for(int y=0;y<4;){
         COD_horario=(int)Lista_Cita.getValueAt(x, y);
         Hora_cita=(String)Lista_Cita.getValueAt(x, y+1);
         Fecha_cita=(String)Lista_Cita.getValueAt(x, y+2);
         d.setHoraCita(Hora_cita);
         d.setFechaCita(Fecha_cita);
         d.setCOD_Horario(COD_horario);
         citas.editarHorario(d);
         y=4;
         }
         if("".equals(Hora_cita) && "".equals(Fecha_cita)){
         break;
         }
        }
                    
    }//GEN-LAST:event_btnEditarMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       CargarTabla();
    }//GEN-LAST:event_formWindowOpened

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        String busqueda=txtfBuscar.getText();
        Mostrar(busqueda);
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnActualizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnActualizarMouseClicked
        CargarTabla();
        
    }//GEN-LAST:event_btnActualizarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Horarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Lista_Cita;
    private javax.swing.JMenu btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JMenu btnEditar;
    private javax.swing.JMenu btnEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtfBuscar;
    // End of variables declaration//GEN-END:variables
}
