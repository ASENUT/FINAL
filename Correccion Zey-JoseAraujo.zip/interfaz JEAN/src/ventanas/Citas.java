/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;
import Datos.*;
import Logico.LCitas;


import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author alumnos
 */
public class Citas extends javax.swing.JFrame {
     LCitas citas= new LCitas();
     String accion ="";//Para saber que accion realizar, guardar, eliminar, editar
    public Citas() {
        initComponents();
       this.setLocationRelativeTo(null); // centrar en pantalla
        inhabilitar();
        LimitaCaracteres(txtHoraCita,5);
        Sesiones.setText("0");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtHoraCita = new javax.swing.JTextField();
        Tipo_CitaBox = new javax.swing.JComboBox();
        DespB = new javax.swing.JButton();
        txtFechaCita = new com.toedter.calendar.JDateChooser();
        txtCedula = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Sesiones = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Tratamiento = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("CI:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(550, 300));
        setName("Citas"); // NOI18N
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Hora Cita:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Fecha Cita:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, -1, 20));

        txtHoraCita.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtHoraCitaCaretUpdate(evt);
            }
        });
        txtHoraCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraCitaActionPerformed(evt);
            }
        });
        txtHoraCita.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHoraCitaKeyTyped(evt);
            }
        });
        getContentPane().add(txtHoraCita, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 150, -1));

        Tipo_CitaBox.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Tipo_CitaBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Estética", "Nutrición" }));
        getContentPane().add(Tipo_CitaBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, -1, -1));

        DespB.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        DespB.setText("Desplegar Horarios");
        DespB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DespBMouseClicked(evt);
            }
        });
        DespB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DespBActionPerformed(evt);
            }
        });
        getContentPane().add(DespB, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 130, -1, -1));
        getContentPane().add(txtFechaCita, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 180, -1));

        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, 150, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Tratamiento:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        Sesiones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SesionesActionPerformed(evt);
            }
        });
        Sesiones.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                SesionesKeyTyped(evt);
            }
        });
        getContentPane().add(Sesiones, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 50, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("CI:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Sesiones");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        Tratamiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TratamientoActionPerformed(evt);
            }
        });
        Tratamiento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TratamientoKeyTyped(evt);
            }
        });
        getContentPane().add(Tratamiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 150, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 280));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/New.png"))); // NOI18N
        jMenu4.setText("Nuevo");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu4);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        jMenu1.setText("Guardar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DespBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DespBMouseClicked
        // TODO add your handling code here:
        Horarios h = new Horarios();
        h.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DespBMouseClicked

    void inhabilitar (){
        txtHoraCita.setEnabled(false);
        Tipo_CitaBox.setEnabled(false);
        txtFechaCita.setEnabled(false);
        txtCedula.setEnabled(false);
        Tratamiento.setEnabled(false);
    }
    
    void habilitar (){
        txtHoraCita.setText("");
        Tipo_CitaBox.setEnabled(true);
        txtFechaCita.setEnabled(true);
        txtCedula.setText("");
        Tratamiento.setEnabled(true);
    }
    
    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        MenuAdministrativo m = new MenuAdministrativo();
        m.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu5MouseClicked

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu4MouseClicked
        habilitar();
         txtHoraCita.setEnabled(true);
          txtCedula.setEnabled(true);
          Tratamiento.setText("");
          Sesiones.setText("0");
        accion="guardar";
    }//GEN-LAST:event_jMenu4MouseClicked

    private void txtHoraCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraCitaActionPerformed
        txtHoraCita.transferFocus();
    }//GEN-LAST:event_txtHoraCitaActionPerformed

    private void DespBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DespBActionPerformed

        
    }//GEN-LAST:event_DespBActionPerformed

    private void txtHoraCitaCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtHoraCitaCaretUpdate
      
        
    }//GEN-LAST:event_txtHoraCitaCaretUpdate

    private void txtHoraCitaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtHoraCitaKeyTyped
            char C  = evt.getKeyChar();
              if(Character.isLetter(C))
              {               
                //getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                evt.consume();
                JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");
                txtHoraCita.setCursor(null);
              }        
    }//GEN-LAST:event_txtHoraCitaKeyTyped

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
        char C  = evt.getKeyChar();
              if(Character.isLetter(C))
              {               
                //getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                evt.consume();
                JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");
                txtHoraCita.setCursor(null);
              } 
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        txtCedula.transferFocus();
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
       boolean inserta=false;
        if( txtHoraCita.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Hora de Cita","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else if ( txtFechaCita.getDate()==null ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Fecha de Cita","Error!",JOptionPane.ERROR_MESSAGE);
            
        }
        else if ( txtCedula.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Cedula","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else if ( Tratamiento.getText().isEmpty() ){
            
            JOptionPane.showMessageDialog(null, "Ingrese Tratamiento","Error!",JOptionPane.ERROR_MESSAGE);
            
        }else {
            
                                //ingresos

            String HoraCitaI = txtHoraCita.getText();
            String CedulaCliente = txtCedula.getText();
            String Sesion =Sesiones.getText();
            String Trata=Tratamiento.getText();

                                 //fecha

            int anio = txtFechaCita.getCalendar().get( Calendar.YEAR );
            int mes = txtFechaCita.getCalendar().get( Calendar.MONTH );
            int dia = txtFechaCita.getCalendar().get( Calendar.DAY_OF_MONTH );
            String fecha = anio+"-"+(mes+1)+"-"+dia;
            String FechaCitaI = fecha; 
            String Tipo_Cita=Tipo_CitaBox.getSelectedItem().toString();
            //Pasa los valores a su respectiva clase para utilizar en otro JFrame
            DCitas d=new DCitas();
            String Validar=citas.Validar(CedulaCliente);
            if (Validar.equals("")) {
                JOptionPane.showMessageDialog(null, "El Paciente no esiste");
            }else{
                d.setCliente(CedulaCliente);
                d.setHoraCita(HoraCitaI);
                d.setFechaCita(FechaCitaI);
                d.setTipoCita(Tipo_Cita);
                d.setSesiones(Sesion);
                d.setTratamiento(Trata);
                inserta=citas.insertar(d);
                if (inserta) {
                     JOptionPane.showMessageDialog(Tratamiento, "Se guardo Correctamente");
                }else{
                    JOptionPane.showMessageDialog(Tratamiento, "Error Inesperado, No se Guardo los datos");
                }
            }
            
        }
    }//GEN-LAST:event_jMenu1MouseClicked

    private void SesionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SesionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SesionesActionPerformed

    private void SesionesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SesionesKeyTyped
         char C  = evt.getKeyChar();
              if(Character.isLetter(C))
              {               
                //getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                evt.consume();
                JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");
                txtHoraCita.setCursor(null);
              } 
    }//GEN-LAST:event_SesionesKeyTyped

    private void TratamientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TratamientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TratamientoActionPerformed

    private void TratamientoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TratamientoKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_TratamientoKeyTyped
    public void LimitaCaracteres(JTextField a, int lim)
    {
        a.addKeyListener(new KeyListener() {
           @Override
            public void keyTyped(KeyEvent ke) {
              char c  = ke.getKeyChar();
              if( a.getText().length() == lim )
              {               
                ///getToolKit().beep();
                Toolkit.getDefaultToolkit().beep();
                ke.consume();
                
              }                              
            }
                
           @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

           @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }           
      });
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Citas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Citas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Citas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Citas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Citas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DespB;
    private javax.swing.JTextField Sesiones;
    private javax.swing.JComboBox Tipo_CitaBox;
    private javax.swing.JTextField Tratamiento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField txtCedula;
    private com.toedter.calendar.JDateChooser txtFechaCita;
    private javax.swing.JTextField txtHoraCita;
    // End of variables declaration//GEN-END:variables
}
